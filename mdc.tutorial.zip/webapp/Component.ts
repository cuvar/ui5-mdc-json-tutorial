import UIComponent from "sap/ui/core/UIComponent"

/**
 * @namespace mdc.tutorial
 */
export default class Component extends UIComponent {}